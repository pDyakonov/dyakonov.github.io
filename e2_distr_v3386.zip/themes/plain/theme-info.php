<?php return array (

  'index' => 1,

  'display_name' => array (
    'en' => 'Plain',
    'ru' => 'Простая',
    'uk' => 'Звичайна',
  ),

  'colors' => array (
    'background' => '#fff',
    'headings' => '#000',
    'text' => '#000',
    'link' => '#0060a0',
  ),

  'meta_viewport' => 'width=device-width, initial-scale=1',

); ?>