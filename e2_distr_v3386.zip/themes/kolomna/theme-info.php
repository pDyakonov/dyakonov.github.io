<?php return array (

  'index' => 14,

  'display_name' => array (
    'en' => 'Kolomna',
    'ru' => 'Коломна',
    'uk' => 'Коломна',
  ),

  'colors' => array (
    'background' => '#FEFAEC',#151c2c
    'headings' => '#000',
    'text' => '#625772',
    'link' => '#F38181',
    // http://colorhunt.co/c/79451
  ),

  'based_on' => 'plain',
  'meta_viewport' => 'width=device-width, initial-scale=1',

); ?>