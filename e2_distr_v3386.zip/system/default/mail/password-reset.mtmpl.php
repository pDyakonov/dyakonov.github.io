<?= _S ('em--follow-this-link') ?> 
<?= $content['reset-href'] ?> 


<?= _S ('em--created-automatically') ?>