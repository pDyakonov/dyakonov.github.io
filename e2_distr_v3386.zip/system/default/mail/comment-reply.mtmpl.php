<?= $content['reply-text']?> 
	<?= $content['blog-author'] ?> 

<?= $content['comment-href'] ?> 


<?= _S ('em--created-automatically') ?>